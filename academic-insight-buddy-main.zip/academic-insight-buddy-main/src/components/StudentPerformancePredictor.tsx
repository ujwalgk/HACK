
import React, { useState } from "react";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Form, 
  FormControl, 
  FormDescription, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { toast } from "@/components/ui/use-toast";
import { ScrollArea } from "@/components/ui/scroll-area";
import ResultsDisplay from "./ResultsDisplay";
import { 
  BookOpen,
  Clock, 
  GraduationCap, 
  Percent, 
  UserRound, 
  Wifi, 
  Trophy,
  ArrowRight
} from "lucide-react";

// Define form schema for validation
const formSchema = z.object({
  gender: z.enum(["Male", "Female"], {
    required_error: "Please select a gender.",
  }),
  studyHours: z.coerce.number().min(0).max(168).default(10),
  attendanceRate: z.coerce.number().min(0).max(100).default(75),
  pastExamScores: z.coerce.number().min(0).max(100).default(70),
  parentalEducation: z.enum(["High School", "Bachelors", "Masters", "PhD"], {
    required_error: "Please select parental education level.",
  }),
  internetAccess: z.enum(["Yes", "No"], {
    required_error: "Please select internet access option.",
  }),
  extracurricular: z.enum(["Yes", "No"], {
    required_error: "Please select extracurricular activities option.",
  }),
});

type FormValues = z.infer<typeof formSchema>;

const StudentPerformancePredictor: React.FC = () => {
  const [prediction, setPrediction] = useState<any | null>(null);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      gender: "Male",
      studyHours: 10,
      attendanceRate: 75,
      pastExamScores: 70,
      parentalEducation: "Bachelors",
      internetAccess: "Yes",
      extracurricular: "Yes",
    },
  });

  function onSubmit(data: FormValues) {
    // Here we would normally send this data to a backend API
    // For demo, we'll simulate a prediction
    
    // Mock backend prediction logic
    const mockPrediction = simulatePrediction(data);
    
    setPrediction(mockPrediction);
    
    toast({
      title: "Prediction complete!",
      description: "Your performance prediction has been generated.",
    });
  }

  function simulatePrediction(data: FormValues) {
    // Simple mock logic to simulate prediction
    // In real app, this would come from backend API call
    const studyHoursScore = data.studyHours / 30 * 100;
    const attendanceScore = data.attendanceRate;
    const pastScores = data.pastExamScores;
    
    // Education level impact
    let educationBonus = 0;
    switch(data.parentalEducation) {
      case "High School": educationBonus = 0; break;
      case "Bachelors": educationBonus = 3; break;
      case "Masters": educationBonus = 5; break;
      case "PhD": educationBonus = 7; break;
    }
    
    // Internet and extracurricular impact
    const internetBonus = data.internetAccess === "Yes" ? 3 : 0;
    const extracurricularImpact = data.extracurricular === "Yes" ? 2 : 0;
    
    // Calculate final score (simulated model)
    let finalScore = (studyHoursScore * 0.3) + 
                     (attendanceScore * 0.3) + 
                     (pastScores * 0.3) + 
                     educationBonus + 
                     internetBonus + 
                     extracurricularImpact;
                     
    finalScore = Math.min(Math.max(Math.round(finalScore), 0), 100);
    
    // Determine pass/fail (>=60 is pass)
    const xgboostPass = finalScore >= 60;
    const logisticPass = finalScore >= 58; // Slight difference to show model variance
    
    // Generate analysis message
    let analysis = "";
    if (finalScore >= 75) {
      analysis = `Based on your inputs, you're heading for great success! 🌟 An expected final score of **${finalScore} out of 100** is excellent. Your combination of ${data.studyHours} study hours per week and ${data.attendanceRate}% attendance rate is working well. Keep up the great work!`;
    } else if (finalScore >= 60) {
      analysis = `Based on your inputs, you're likely to **Pass** the exam! 🎉 Your expected final score is **around ${finalScore} out of 100**. Great job maintaining consistent study hours and past scores! Improving attendance a bit more could boost your score further.`;
    } else {
      analysis = `Based on your inputs, you may need some additional focus to pass. Your expected score is **${finalScore} out of 100**. Consider increasing your weekly study hours (currently ${data.studyHours}) and improving your attendance rate (currently ${data.attendanceRate}%). With some additional effort, you can definitely succeed!`;
    }
    
    return {
      rawInputs: data,
      processedInputs: {
        studyHoursNormalized: (data.studyHours / 30).toFixed(2),
        attendanceImpact: (data.attendanceRate / 100).toFixed(2),
        parentalEducationFactor: (educationBonus / 10).toFixed(2),
        pastPerformanceIndicator: (data.pastExamScores / 100).toFixed(2),
        internetAccessFactor: (internetBonus / 10).toFixed(2),
        extracurricularFactor: (extracurricularImpact / 10).toFixed(2),
      },
      predictions: {
        xgboostResult: xgboostPass ? "Pass" : "Fail",
        logisticResult: logisticPass ? "Pass" : "Fail",
        finalScore: finalScore,
      },
      analysis: analysis
    };
  }

  return (
    <div className="min-h-screen w-full gradient-bg py-8 px-4">
      <div className="max-w-5xl mx-auto">
        <div className="mb-8 text-center">
          <h1 className="text-3xl md:text-4xl font-bold mb-2 text-app-blue">Academic Insight Buddy</h1>
          <p className="text-slate-600 max-w-2xl mx-auto">
            Predict your academic performance by entering your details below. Our model will analyze your inputs and provide personalized insights.
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Input Form */}
          <Card className="lg:col-span-1 shadow-md">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-app-blue">
                <GraduationCap className="h-5 w-5" /> 
                Student Information
              </CardTitle>
              <CardDescription>
                Enter your details to get performance predictions
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <FormField
                    control={form.control}
                    name="gender"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="flex items-center gap-2">
                          <UserRound className="h-4 w-4" /> Gender
                        </FormLabel>
                        <Select 
                          onValueChange={field.onChange} 
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select gender" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="Male">Male</SelectItem>
                            <SelectItem value="Female">Female</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="studyHours"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="flex items-center gap-2">
                          <Clock className="h-4 w-4" /> Study Hours per Week
                        </FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            min={0} 
                            max={168} 
                            {...field}
                          />
                        </FormControl>
                        <FormDescription>
                          Weekly hours dedicated to studying
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="attendanceRate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="flex items-center gap-2">
                          <Percent className="h-4 w-4" /> Attendance Rate (%)
                        </FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            min={0} 
                            max={100} 
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="pastExamScores"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="flex items-center gap-2">
                          <BookOpen className="h-4 w-4" /> Past Exam Scores
                        </FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            min={0} 
                            max={100} 
                            {...field}
                          />
                        </FormControl>
                        <FormDescription>
                          Average of previous exams (0-100)
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="parentalEducation"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="flex items-center gap-2">
                          <GraduationCap className="h-4 w-4" /> Parental Education Level
                        </FormLabel>
                        <Select 
                          onValueChange={field.onChange} 
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select education level" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="High School">High School</SelectItem>
                            <SelectItem value="Bachelors">Bachelors</SelectItem>
                            <SelectItem value="Masters">Masters</SelectItem>
                            <SelectItem value="PhD">PhD</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="internetAccess"
                    render={({ field }) => (
                      <FormItem className="space-y-3">
                        <FormLabel className="flex items-center gap-2">
                          <Wifi className="h-4 w-4" /> Internet Access at Home
                        </FormLabel>
                        <FormControl>
                          <RadioGroup
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                            className="flex space-x-6"
                          >
                            <FormItem className="flex items-center space-x-2 space-y-0">
                              <FormControl>
                                <RadioGroupItem value="Yes" />
                              </FormControl>
                              <FormLabel className="font-normal">
                                Yes
                              </FormLabel>
                            </FormItem>
                            <FormItem className="flex items-center space-x-2 space-y-0">
                              <FormControl>
                                <RadioGroupItem value="No" />
                              </FormControl>
                              <FormLabel className="font-normal">
                                No
                              </FormLabel>
                            </FormItem>
                          </RadioGroup>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="extracurricular"
                    render={({ field }) => (
                      <FormItem className="space-y-3">
                        <FormLabel className="flex items-center gap-2">
                          <Trophy className="h-4 w-4" /> Extracurricular Activities
                        </FormLabel>
                        <FormControl>
                          <RadioGroup
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                            className="flex space-x-6"
                          >
                            <FormItem className="flex items-center space-x-2 space-y-0">
                              <FormControl>
                                <RadioGroupItem value="Yes" />
                              </FormControl>
                              <FormLabel className="font-normal">
                                Yes
                              </FormLabel>
                            </FormItem>
                            <FormItem className="flex items-center space-x-2 space-y-0">
                              <FormControl>
                                <RadioGroupItem value="No" />
                              </FormControl>
                              <FormLabel className="font-normal">
                                No
                              </FormLabel>
                            </FormItem>
                          </RadioGroup>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button 
                    type="submit" 
                    className="w-full bg-app-blue hover:bg-app-blue/90 text-white flex items-center justify-center gap-2"
                  >
                    Generate Prediction 
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
          
          {/* Results Area */}
          <div className="lg:col-span-2">
            <ScrollArea className="h-full max-h-[800px]">
              {prediction ? (
                <ResultsDisplay prediction={prediction} />
              ) : (
                <Card className="h-full flex items-center justify-center p-8 bg-white/50 shadow-md">
                  <div className="text-center">
                    <GraduationCap className="h-16 w-16 text-app-blue/30 mx-auto mb-4" />
                    <CardTitle className="text-xl text-slate-500 mb-2">No Prediction Yet</CardTitle>
                    <CardDescription className="max-w-md mx-auto">
                      Fill in your information in the form and click "Generate Prediction" to see your academic performance analysis.
                    </CardDescription>
                  </div>
                </Card>
              )}
            </ScrollArea>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StudentPerformancePredictor;
