
import React from "react";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { 
  CheckCircle2,
  XCircle,
  BarChart3,
  Archive,
  BarChart4,
  Award,
  BookOpen,
  Activity
} from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";

interface PredictionData {
  rawInputs: {
    gender: string;
    studyHours: number;
    attendanceRate: number;
    pastExamScores: number;
    parentalEducation: string;
    internetAccess: string;
    extracurricular: string;
  };
  processedInputs: {
    studyHoursNormalized: string;
    attendanceImpact: string;
    parentalEducationFactor: string;
    pastPerformanceIndicator: string;
    internetAccessFactor: string;
    extracurricularFactor: string;
  };
  predictions: {
    xgboostResult: "Pass" | "Fail";
    logisticResult: "Pass" | "Fail";
    finalScore: number;
  };
  analysis: string;
}

const ResultsDisplay: React.FC<{ prediction: PredictionData }> = ({ prediction }) => {
  const { rawInputs, processedInputs, predictions, analysis } = prediction;
  
  // Calculate if student is likely to pass (based on both models)
  const likelyToPass = 
    (predictions.xgboostResult === "Pass" && predictions.logisticResult === "Pass") || 
    (predictions.xgboostResult === "Pass" && predictions.logisticResult !== "Pass") || 
    (predictions.xgboostResult !== "Pass" && predictions.logisticResult === "Pass");
    
  // Format the analysis text with markdown-like syntax
  const formattedAnalysis = analysis.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
  
  return (
    <div className="space-y-6">
      {/* Top Results Summary */}
      <Card className="shadow-md">
        <CardHeader className="bg-gradient-to-r from-app-blue/10 to-app-cyan/10 rounded-t-lg">
          <CardTitle className="text-xl flex items-center gap-2">
            <Award className="h-5 w-5 text-app-blue" />
            Prediction Results
          </CardTitle>
          <CardDescription>
            Based on your inputs, here's what our models predict
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex flex-col items-center justify-center p-4 bg-slate-50 rounded-lg">
              <div className="text-xs uppercase text-slate-500 font-semibold mb-2">XGBoost Model</div>
              <div className="flex items-center gap-2">
                {predictions.xgboostResult === "Pass" ? (
                  <CheckCircle2 className="h-6 w-6 text-app-green" />
                ) : (
                  <XCircle className="h-6 w-6 text-app-red" />
                )}
                <span className={`text-lg font-bold ${predictions.xgboostResult === "Pass" ? "text-app-green" : "text-app-red"}`}>
                  {predictions.xgboostResult}
                </span>
              </div>
            </div>
            
            <div className="flex flex-col items-center justify-center p-4 bg-slate-50 rounded-lg">
              <div className="text-xs uppercase text-slate-500 font-semibold mb-2">Logistic Regression</div>
              <div className="flex items-center gap-2">
                {predictions.logisticResult === "Pass" ? (
                  <CheckCircle2 className="h-6 w-6 text-app-green" />
                ) : (
                  <XCircle className="h-6 w-6 text-app-red" />
                )}
                <span className={`text-lg font-bold ${predictions.logisticResult === "Pass" ? "text-app-green" : "text-app-red"}`}>
                  {predictions.logisticResult}
                </span>
              </div>
            </div>
            
            <div className="flex flex-col items-center justify-center p-4 bg-slate-50 rounded-lg">
              <div className="text-xs uppercase text-slate-500 font-semibold mb-2">Predicted Score</div>
              <div className="flex items-center gap-2">
                <span 
                  className={`text-2xl font-bold ${
                    predictions.finalScore >= 75 
                      ? "text-app-green" 
                      : predictions.finalScore >= 60 
                      ? "text-app-blue" 
                      : "text-app-red"
                  }`}
                >
                  {predictions.finalScore}/100
                </span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* Analysis Card */}
      <Card className="analysis-card shadow-md">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5 text-app-blue" />
            Analysis Summary
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div 
            className="prose prose-slate max-w-none"
            dangerouslySetInnerHTML={{ __html: formattedAnalysis }}
          />
          
          <div className="mt-4 flex flex-wrap gap-2">
            {rawInputs.studyHours < 10 && (
              <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-200">Increase Study Hours</Badge>
            )}
            {rawInputs.attendanceRate < 70 && (
              <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-200">Improve Attendance</Badge>
            )}
            {predictions.finalScore >= 75 && (
              <Badge className="bg-app-light-green text-app-green hover:bg-green-200">Excellent Performance</Badge>
            )}
            {rawInputs.extracurricular === "Yes" && (
              <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-200">Active in Extracurriculars</Badge>
            )}
          </div>
        </CardContent>
      </Card>
      
      {/* Processed Inputs Card */}
      <Card className="shadow-md">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5 text-app-blue" />
            Processed Inputs
          </CardTitle>
          <CardDescription>
            How our model processes your input data
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Factor</TableHead>
                <TableHead>Normalized Value</TableHead>
                <TableHead>Impact</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              <TableRow>
                <TableCell className="font-medium">Study Hours</TableCell>
                <TableCell>{processedInputs.studyHoursNormalized}</TableCell>
                <TableCell>
                  <Badge className={`${parseFloat(processedInputs.studyHoursNormalized) > 0.3 ? "bg-app-green/20 text-app-green" : "bg-app-yellow/20 text-app-yellow"}`}>
                    {parseFloat(processedInputs.studyHoursNormalized) > 0.3 ? "High" : "Medium"}
                  </Badge>
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">Attendance</TableCell>
                <TableCell>{processedInputs.attendanceImpact}</TableCell>
                <TableCell>
                  <Badge className={`${parseFloat(processedInputs.attendanceImpact) > 0.7 ? "bg-app-green/20 text-app-green" : "bg-app-yellow/20 text-app-yellow"}`}>
                    {parseFloat(processedInputs.attendanceImpact) > 0.7 ? "High" : "Medium"}
                  </Badge>
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">Past Performance</TableCell>
                <TableCell>{processedInputs.pastPerformanceIndicator}</TableCell>
                <TableCell>
                  <Badge className={`${parseFloat(processedInputs.pastPerformanceIndicator) > 0.7 ? "bg-app-green/20 text-app-green" : "bg-app-yellow/20 text-app-yellow"}`}>
                    {parseFloat(processedInputs.pastPerformanceIndicator) > 0.7 ? "High" : "Medium"}
                  </Badge>
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">Parental Education</TableCell>
                <TableCell>{processedInputs.parentalEducationFactor}</TableCell>
                <TableCell>
                  <Badge className={`${parseFloat(processedInputs.parentalEducationFactor) > 0.5 ? "bg-app-green/20 text-app-green" : "bg-app-yellow/20 text-app-yellow"}`}>
                    {parseFloat(processedInputs.parentalEducationFactor) > 0.5 ? "High" : "Medium"}
                  </Badge>
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">Internet Access</TableCell>
                <TableCell>{processedInputs.internetAccessFactor}</TableCell>
                <TableCell>
                  <Badge className={`${parseFloat(processedInputs.internetAccessFactor) > 0 ? "bg-app-green/20 text-app-green" : "bg-app-yellow/20 text-app-yellow"}`}>
                    {parseFloat(processedInputs.internetAccessFactor) > 0 ? "Positive" : "Neutral"}
                  </Badge>
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">Extracurricular</TableCell>
                <TableCell>{processedInputs.extracurricularFactor}</TableCell>
                <TableCell>
                  <Badge className={`${parseFloat(processedInputs.extracurricularFactor) > 0 ? "bg-app-green/20 text-app-green" : "bg-app-yellow/20 text-app-yellow"}`}>
                    {parseFloat(processedInputs.extracurricularFactor) > 0 ? "Positive" : "Neutral"}
                  </Badge>
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      
      {/* Raw Inputs Card */}
      <Card className="shadow-md">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Archive className="h-5 w-5 text-app-blue" />
            Raw Inputs
          </CardTitle>
          <CardDescription>
            Values you entered in the form
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <div className="flex justify-between py-1 border-b">
                <span className="text-slate-600">Gender</span>
                <span className="font-medium">{rawInputs.gender}</span>
              </div>
              <div className="flex justify-between py-1 border-b">
                <span className="text-slate-600">Study Hours/Week</span>
                <span className="font-medium">{rawInputs.studyHours}</span>
              </div>
              <div className="flex justify-between py-1 border-b">
                <span className="text-slate-600">Attendance Rate</span>
                <span className="font-medium">{rawInputs.attendanceRate}%</span>
              </div>
              <div className="flex justify-between py-1 border-b">
                <span className="text-slate-600">Past Exam Scores</span>
                <span className="font-medium">{rawInputs.pastExamScores}/100</span>
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between py-1 border-b">
                <span className="text-slate-600">Parental Education</span>
                <span className="font-medium">{rawInputs.parentalEducation}</span>
              </div>
              <div className="flex justify-between py-1 border-b">
                <span className="text-slate-600">Internet Access</span>
                <span className="font-medium">{rawInputs.internetAccess}</span>
              </div>
              <div className="flex justify-between py-1 border-b">
                <span className="text-slate-600">Extracurricular</span>
                <span className="font-medium">{rawInputs.extracurricular}</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ResultsDisplay;
