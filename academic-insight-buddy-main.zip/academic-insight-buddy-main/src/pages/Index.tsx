
import StudentPerformancePredictor from "@/components/StudentPerformancePredictor";

const Index = () => {
  return (
    <StudentPerformancePredictor />
  );
};

export default Index;
